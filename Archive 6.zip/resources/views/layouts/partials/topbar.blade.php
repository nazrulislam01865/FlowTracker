<header class="topbar ft-shell-topbar">
    <button id="mobileMenu" class="mobile-menu">☰</button>
    <div class="top-actions">
        <span class="lang-btn" aria-label="Language">中文</span>
        @if(auth()->user()->canModule('notifications','view'))
            <a id="flowtrackNotificationBell" class="icon-btn" href="{{ route('notifications') }}" wire:navigate aria-label="Notifications"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg>@if(\App\Models\FlowNotification::where('user_id',auth()->id())->whereNull('read_at')->exists())<span id="flowtrackNotificationDot" class="dot"></span>@endif</a>
        @endif
        <a class="icon-btn" href="{{ route('profile') }}" wire:navigate aria-label="Profile"><x-ui.avatar :name="auth()->user()->name" :size="28" /></a>
    </div>
</header>
