<?php

namespace App\Livewire\Jobs;

use App\Livewire\Concerns\UsesPagePlaceholder;

use App\Models\Client;
use App\Models\Document;
use App\Models\FlowJob;
use App\Models\FlowJobItem;
use App\Models\Task;
use App\Models\User;
use App\Models\Workflow;
use App\Models\WorkflowPhase;
use App\Services\JobService;
use App\Services\MasterDataService;
use App\Services\TaskService;
use App\Support\BoardLaneResolver;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Livewire\Component;
use Livewire\Attributes\On;
use Livewire\Attributes\Url;
use Livewire\WithFileUploads;
use Livewire\WithPagination;
use Throwable;

class Index extends Component
{
    use UsesPagePlaceholder;
    use WithPagination, WithFileUploads;

    public string $search = '';
    public string $phase = '';
    public string $health = '';
    public string $client = '';
    public string $owner = '';
    public string $delivery = '';
    public string $invoice = '';
    public string $priorityFilter = '';
    public string $jobStatusFilter = '';
    public string $quickFilter = 'all';
    public bool $showMoreFilters = false;
    public int $perPage = 10;
    public array $selectedJobIds = [];

    #[Url(as: 'open', history: true)]
    public ?int $selectedJobId = null;

    #[Url(as: 'task', history: true)]
    public ?int $selectedTaskId = null;
    public string $detailTab = 'overview';
    public array $expandedPhaseIds = [];
    public string $jobTaskSearch = '';
    public bool $showCreate = false;

    public string $jobTitle = '';
    public string $priority = 'Medium';
    public ?int $clientId = null;
    public ?int $workflowId = null;
    public ?int $workflowPhaseId = null;
    public ?int $ownerId = null;
    public ?int $coordinatorId = null;
    public string $deliveryDate = '';
    public string $description = '';
    public array $jobItems = [];
    public array $jobAttachments = [];
    public array $jobDocumentUploads = [];
    public ?int $jobDocumentTaskId = null;
    public ?int $existingDocumentId = null;
    public bool $showDocumentPicker = false;

    public string $taskStatus = 'Ready';
    public ?int $taskAssigneeId = null;
    public int $taskProgress = 0;
    public bool $taskAttention = false;
    public string $taskAttentionReason = '';
    public string $taskComment = '';
    public string $newChecklistItem = '';
    public string $taskActivityTab = 'all';
    public int $taskActivityPage = 1;
    public string $jobComment = '';
    public string $jobActivityTab = 'all';
    public int $jobActivityPage = 1;
    public int $activityPerPage = 30;
    public array $taskDocumentUploads = [];
    public ?int $taskExistingDocumentId = null;
    public bool $showTaskDocumentPicker = false;

    public function mount(): void
    {
        $this->search = (string) request('search', '');
        $this->selectedJobId = request()->integer('open') ?: null;
        $this->selectedTaskId = request()->integer('task') ?: null;
        $this->showCreate = request()->boolean('create');
        $this->deliveryDate = now()->addMonth()->format('Y-m-d');
        $this->workflowId = Workflow::where('is_active', true)->value('id');
        $clientQuery = app(\App\Services\ClientService::class)->visibleQuery(auth()->user())->where('is_active', true);
        $requestedClientId = request()->integer('client') ?: null;
        $this->clientId = $requestedClientId && (clone $clientQuery)->whereKey($requestedClientId)->exists()
            ? $requestedClientId
            : $clientQuery->value('id');
        $this->ownerId = auth()->id();
        $this->coordinatorId = auth()->id();
        $this->jobItems = [['category' => '', 'product' => '', 'quantity' => 1000]];
        $this->setDefaultStartPhase();

        if ($this->selectedTaskId) {
            $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($this->selectedTaskId);
            $this->selectedJobId = $this->selectedJobId ?: $task->flow_job_id;
            $this->loadTaskForm($this->selectedTaskId);
        }

        if ($this->selectedJobId) $this->prepareSelectedJob($this->selectedJobId);
    }

    public function updatedWorkflowId(): void { $this->setDefaultStartPhase(); }
    public function updatedSearch(): void { $this->resetJobSelection(); }
    public function updatedPhase(): void { $this->resetJobSelection(); }
    public function updatedHealth(): void { $this->resetJobSelection(); }
    public function updatedClient(): void { $this->resetJobSelection(); }
    public function updatedOwner(): void { $this->resetJobSelection(); }
    public function updatedDelivery(): void { $this->resetJobSelection(); }
    public function updatedInvoice(): void { $this->resetJobSelection(); }
    public function updatedPriorityFilter(): void { $this->resetJobSelection(); }
    public function updatedJobStatusFilter(): void { $this->resetJobSelection(); }

    public function clearFilters(): void
    {
        $this->reset(['search','phase','health','client','owner','delivery','invoice','priorityFilter','jobStatusFilter']);
        $this->quickFilter = 'all';
        $this->resetJobSelection();
    }

    public function setQuickFilter(string $filter): void
    {
        abort_unless(in_array($filter, ['all','attention','due_week','waiting','invoice','completed'], true), 422);
        $this->quickFilter = $filter;
        $this->resetJobSelection();
    }

    public function toggleMoreFilters(): void { $this->showMoreFilters = !$this->showMoreFilters; }

    public function toggleSelectAllJobs(): void
    {
        $ids = app(JobService::class)->filteredIds(auth()->user(), $this->jobFilters());

        if ($ids->isNotEmpty() && count($this->selectedJobIds) === $ids->count()) {
            $selected = collect($this->selectedJobIds)->map(fn ($id) => (int) $id)->sort()->values();
            if ($selected->all() === $ids->sort()->values()->all()) {
                $this->selectedJobIds = [];
                return;
            }
        }

        $this->selectedJobIds = $ids->all();
    }

    public function bulkUpdateJobs(string $action): void
    {
        abort_unless(in_array($action, ['deactivate','cancel','delete'], true), 422);

        $ids = collect($this->selectedJobIds)
            ->map(fn ($id) => (int) $id)
            ->filter()
            ->unique()
            ->values();

        if ($ids->isEmpty()) return;

        $service = app(JobService::class);
        $actor = auth()->user();
        $jobs = $service->visibleQuery($actor)->whereIn('id', $ids)->get();

        foreach ($jobs as $job) {
            match ($action) {
                'deactivate' => $service->deactivate($job, $actor),
                'cancel' => $service->cancel($job, $actor),
                'delete' => $service->delete($job, $actor),
            };
        }

        $this->resetJobSelection();
        session()->flash('success', match ($action) {
            'deactivate' => 'Selected Jobs deactivated.',
            'cancel' => 'Selected Jobs cancelled.',
            'delete' => 'Selected Jobs deleted.',
        });
    }
    public function openCreate(): void { abort_unless(auth()->user()->canAccess('jobs.create'), 403); $this->showCreate = true; }
    public function closeCreate(): void { $this->showCreate = false; $this->resetValidation(); }
    public function addProductRow(): void { $this->jobItems[] = ['category' => '', 'product' => '', 'quantity' => 1]; }
    public function removeProductRow(int $index): void { if (count($this->jobItems) <= 1) return; unset($this->jobItems[$index]); $this->jobItems = array_values($this->jobItems); }

    public function openJob(int $id): void
    {
        $this->selectedJobId = $id;
        $this->selectedTaskId = null;
        $this->detailTab = 'overview';
        $this->jobTaskSearch = '';
        $this->jobDocumentUploads = [];
        $this->jobDocumentTaskId = null;
        $this->existingDocumentId = null;
        $this->showDocumentPicker = false;
        $this->jobComment = '';
        $this->jobActivityTab = 'all';
        $this->jobActivityPage = 1;
        $this->prepareSelectedJob($id);
    }

    public function closeDrawer(): void
    {
        $this->selectedJobId = null;
        $this->selectedTaskId = null;
        $this->expandedPhaseIds = [];
        $this->jobTaskSearch = '';
        $this->jobDocumentUploads = [];
        $this->jobDocumentTaskId = null;
        $this->existingDocumentId = null;
        $this->showDocumentPicker = false;
    }

    public function setDetailTab(string $tab): void
    {
        abort_unless(in_array($tab, ['overview','workflow','documents'], true), 422);
        $this->detailTab = $tab;
        if ($tab === 'documents' && $this->selectedJobId) {
            $this->setDefaultDocumentTask();
        }
    }

    public function toggleJobPhase(int $phaseId): void
    {
        if (in_array($phaseId, $this->expandedPhaseIds, true)) {
            $this->expandedPhaseIds = array_values(array_filter($this->expandedPhaseIds, fn ($id) => (int) $id !== $phaseId));
        } else {
            $this->expandedPhaseIds[] = $phaseId;
            $this->expandedPhaseIds = array_values(array_unique(array_map('intval', $this->expandedPhaseIds)));
        }
    }

    public function expandAllJobPhases(): void
    {
        if (!$this->selectedJobId) return;
        $job = app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        $this->expandedPhaseIds = $job->workflow->phases->pluck('id')->map(fn ($id) => (int) $id)->values()->all();
    }

    public function collapseAllJobPhases(): void { $this->expandedPhaseIds = []; }

    public function createJob(): void { $this->persistJob(false); }
    public function saveDraft(): void { $this->persistJob(true); }

    private function persistJob(bool $draft): void
    {
        abort_unless(auth()->user()->canAccess('jobs.create'), 403);
        $data = $this->validate([
            'jobTitle' => ['required','string','max:255'],
            'priority' => ['required','string','max:30'],
            'clientId' => ['required','exists:clients,id'],
            'workflowId' => ['required','exists:workflows,id'],
            'workflowPhaseId' => ['required','exists:workflow_phases,id'],
            'ownerId' => ['required','exists:users,id'],
            'coordinatorId' => ['nullable','exists:users,id'],
            'deliveryDate' => ['required','date'],
            'description' => ['nullable','string'],
            'jobItems' => ['required','array','min:1'],
            'jobItems.*.category' => ['required','string','max:255'],
            'jobItems.*.product' => ['required','string','max:255'],
            'jobItems.*.quantity' => ['required','integer','min:1'],
            'jobAttachments.*' => ['file','max:20480','mimes:pdf,doc,docx,xls,xlsx,jpg,jpeg,png,zip,txt,csv'],
        ]);

        if (count($this->jobAttachments) > 0) {
            abort_unless(auth()->user()->canModule('documents', 'create'), 403);
        }

        $first = collect($data['jobItems'])->first();
        $job = app(JobService::class)->create([
            'title' => $data['jobTitle'],
            'product' => $first['product'],
            'category' => $first['category'],
            'quantity' => collect($data['jobItems'])->sum('quantity'),
            'items' => $data['jobItems'],
            'priority' => $data['priority'],
            'client_id' => $data['clientId'],
            'workflow_id' => $data['workflowId'],
            'workflow_phase_id' => $data['workflowPhaseId'],
            'owner_id' => $data['ownerId'],
            'coordinator_id' => $data['coordinatorId'] ?: $data['ownerId'],
            'delivery_date' => $data['deliveryDate'],
            'description' => $data['description'],
            'draft' => $draft,
        ], auth()->user());

        foreach ($this->jobAttachments as $upload) {
            app(\App\Services\DocumentService::class)->store($upload, [
                'flow_job_id' => $job->id,
                'client_id' => $job->client_id,
                'category' => 'Job attachment',
            ], auth()->user());
        }

        $this->showCreate = false;
        $this->jobAttachments = [];
        $this->selectedJobId = $job->id;
        $this->detailTab = 'overview';
        $this->prepareSelectedJob($job->id);
        session()->flash('success', $draft ? 'Job draft saved.' : 'Job created and all configured Workflow Task Packs were loaded.');
    }

    public function updateJobOwner(int $jobId, mixed $ownerId): void
    {
        abort_unless(auth()->user()->canModule('jobs','assign'), 403);
        $ownerId = $ownerId === '' ? null : (int) $ownerId;
        if ($ownerId) User::where('is_active', true)->findOrFail($ownerId);
        $job = app(JobService::class)->findVisible(auth()->user(), $jobId);
        app(JobService::class)->updateOwner($job, $ownerId, auth()->user());
    }

    public function updateJobCoordinator(int $jobId, mixed $coordinatorId): void
    {
        abort_unless(auth()->user()->canModule('jobs','assign'), 403);
        $coordinatorId = $coordinatorId === '' ? null : (int) $coordinatorId;
        if ($coordinatorId) User::where('is_active', true)->findOrFail($coordinatorId);
        $job = app(JobService::class)->findVisible(auth()->user(), $jobId);
        app(JobService::class)->updateCoordinator($job, $coordinatorId, auth()->user());
    }

    public function updateJobDeliveryDate(int $jobId, mixed $date): void
    {
        abort_unless(auth()->user()->canAccess('jobs.update'), 403);
        $date = trim((string) $date);
        if ($date !== '') validator(['date' => $date], ['date' => ['date']])->validate();
        $job = app(JobService::class)->findVisible(auth()->user(), $jobId);
        app(JobService::class)->updateDeliveryDate($job, $date ?: null, auth()->user());
    }

    public function updateJobPriority(int $jobId, mixed $priority): void
    {
        abort_unless(auth()->user()->canAccess('jobs.update'), 403);
        $priority = trim((string) $priority);
        abort_if($priority === '', 422, 'Priority is required.');
        $job = app(JobService::class)->findVisible(auth()->user(), $jobId);
        app(JobService::class)->updatePriority($job, $priority, auth()->user());
    }

    public function updateJobHealth(int $jobId, mixed $health): void
    {
        abort_unless(auth()->user()->canAccess('jobs.update'), 403);
        $health = trim((string) $health);
        abort_if($health === '', 422, 'Health is required.');
        $job = app(JobService::class)->findVisible(auth()->user(), $jobId);
        app(JobService::class)->updateHealth($job, $health, auth()->user());
    }

    public function updateJobTextField(int $jobId, string $field, mixed $value): void
    {
        abort_unless(auth()->user()->canAccess('jobs.update'), 403);
        $job = app(JobService::class)->findVisible(auth()->user(), $jobId);
        app(JobService::class)->updateTextField($job, $field, (string) $value, auth()->user());
    }

    public function updateJobItem(int $itemId, string $field, mixed $value): void
    {
        abort_unless(auth()->user()->canAccess('jobs.update'), 403);
        abort_unless($this->selectedJobId, 422);
        if ($field === 'category_name') {
            abort_unless(app(MasterDataService::class)->active('product_category')->contains('name', (string) $value), 422, 'Select a valid active product category.');
        }
        if ($field === 'product_name') {
            abort_unless(app(MasterDataService::class)->active('product')->contains('name', (string) $value), 422, 'Select a valid active product.');
        }
        $job = app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        $item = FlowJobItem::where('flow_job_id', $job->id)->findOrFail($itemId);
        app(JobService::class)->updateItem($job, $item, $field, $value, auth()->user());
    }

    public function addJobItem(int $jobId): void
    {
        abort_unless(auth()->user()->canAccess('jobs.update'), 403);
        $job = app(JobService::class)->findVisible(auth()->user(), $jobId);
        $master = app(MasterDataService::class);
        $productRecord = $master->active('product')->first();
        $category = $productRecord?->parent?->name ?: ($master->active('product_category')->first()?->name ?: 'General');
        $product = $productRecord?->name ?: 'New product';
        app(JobService::class)->addItem($job, $category, $product, 1, auth()->user());
    }

    public function removeJobItem(int $itemId): void
    {
        abort_unless(auth()->user()->canAccess('jobs.update'), 403);
        abort_unless($this->selectedJobId, 422);
        $job = app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        $item = FlowJobItem::where('flow_job_id', $job->id)->findOrFail($itemId);
        app(JobService::class)->removeItem($job, $item, auth()->user());
    }

    public function updateTaskAssigneeFromJob(int $taskId, mixed $assigneeId): void
    {
        abort_unless(auth()->user()->canModule('tasks','assign'), 403);
        abort_unless($this->selectedJobId, 422);
        $task = Task::where('flow_job_id', $this->selectedJobId)->findOrFail($taskId);
        $assigneeId = $assigneeId === '' ? null : (int) $assigneeId;
        if ($assigneeId) User::where('is_active', true)->findOrFail($assigneeId);
        app(TaskService::class)->update($task, [
            'status' => $task->status,
            'assignee_id' => $assigneeId ?: $task->assignee_id,
            'progress' => $task->progress,
            'needs_attention' => $task->needs_attention,
            'attention_reason' => $task->attention_reason,
        ], auth()->user());
    }

    public function updateTaskDueDateFromJob(int $taskId, mixed $date): void
    {
        abort_unless(auth()->user()->canAccess('tasks.update') || auth()->user()->canAccess('jobs.update'), 403);
        abort_unless($this->selectedJobId, 422);
        $task = Task::where('flow_job_id', $this->selectedJobId)->findOrFail($taskId);
        $date = trim((string) $date);
        if ($date !== '') validator(['date' => $date], ['date' => ['date']])->validate();
        app(TaskService::class)->updateDueDate($task, $date ?: null, auth()->user());
    }

    public function updatedJobDocumentUploads(): void
    {
        // Livewire first transfers selected files into temporary storage. As
        // soon as that transfer finishes, persist them to the configured
        // FlowTrack document disk and link them to the selected Task Pack
        // requirement. This avoids the confusing state where a browser upload
        // appears to finish but the file is only temporary and disappears on
        // the next render.
        if (!$this->jobDocumentUploads || !$this->jobDocumentTaskId) return;

        $this->uploadJobDocuments();
    }

    public function uploadJobDocuments(): void
    {
        abort_unless(auth()->user()->canModule('documents','create'), 403);
        abort_unless($this->selectedJobId, 422);
        $this->validate([
            'jobDocumentTaskId' => ['required','integer','exists:tasks,id'],
            'jobDocumentUploads' => ['required','array','min:1'],
            'jobDocumentUploads.*' => ['file','max:20480','mimes:pdf,doc,docx,xls,xlsx,jpg,jpeg,png,zip,txt,csv'],
        ]);

        $job = app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        $task = $job->tasks->firstWhere('id', (int) $this->jobDocumentTaskId);
        abort_unless($task && ($task->document_category_id || $task->setupTemplate?->document_category_id), 422, 'Select a Task Pack document requirement for this Job.');

        foreach ($this->jobDocumentUploads as $upload) {
            app(\App\Services\DocumentService::class)->store($upload, [
                'flow_job_id' => $job->id,
                'client_id' => $job->client_id,
                'task_id' => $task->id,
                'require_task_pack_requirement' => true,
            ], auth()->user());
        }

        $this->jobDocumentUploads = [];
        $this->resetValidation(['jobDocumentUploads', 'jobDocumentUploads.*', 'jobDocumentTaskId']);

        // Re-read the Job immediately so the linked file and requirement count
        // are visible in the same Livewire response. Then move the selector to
        // the next missing Task Pack document, if there is one.
        $fresh = app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        $missing = \App\Support\JobDetailPresenter::requiredDocuments($fresh)
            ->first(fn ($requirement) => !$requirement->complete);
        $this->jobDocumentTaskId = $missing?->task?->id ?: $task->id;

        session()->flash('success', 'Document uploaded and linked to '.$task->title.'.');
    }

    public function attachExistingDocument(): void
    {
        abort_unless(auth()->user()->canModule('documents','link'), 403);
        abort_unless($this->selectedJobId, 422);
        $this->validate([
            'jobDocumentTaskId' => ['required','integer','exists:tasks,id'],
            'existingDocumentId' => ['required','integer','exists:documents,id'],
        ]);

        $job = app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        $task = $job->tasks->firstWhere('id', (int) $this->jobDocumentTaskId);
        abort_unless($task && ($task->document_category_id || $task->setupTemplate?->document_category_id), 422, 'Select a Task Pack document requirement for this Job.');
        $source = Document::findOrFail((int) $this->existingDocumentId);
        abort_unless((int) $source->client_id === (int) $job->client_id, 403, 'The selected document does not belong to this client.');
        app(\App\Services\DocumentService::class)->linkExisting($source, $task, auth()->user());
        $this->existingDocumentId = null;
        $this->showDocumentPicker = false;
        session()->flash('success', 'Existing document linked to the selected Task Pack task.');
    }

    public function deleteJobDocument(int $documentId): void
    {
        abort_unless(auth()->user()->canModule('documents','delete'), 403);
        abort_unless($this->selectedJobId, 422);
        $job = app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        $document = Document::where('flow_job_id', $job->id)->findOrFail($documentId);
        app(\App\Services\DocumentService::class)->delete($document, auth()->user());
    }

    public function toggleDocumentPicker(): void
    {
        $this->showDocumentPicker = !$this->showDocumentPicker;
    }

    public function updateTaskStatusFromJob(int $taskId, mixed $status): void
    {
        abort_unless(auth()->user()->canAccess('tasks.update'), 403);
        abort_unless($this->selectedJobId, 422);
        $status = trim((string) $status);
        abort_if($status === '', 422, 'Task status is required.');

        $task = Task::where('flow_job_id', $this->selectedJobId)->findOrFail($taskId);
        app(TaskService::class)->moveStatus($task, $status, auth()->user());
    }

    public function completePhase(): void
    {
        abort_unless(auth()->user()->canAccess('jobs.update'), 403);
        if (!$this->selectedJobId) return;
        try {
            $job = app(JobService::class)->completePhase(app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId), auth()->user());
            $this->expandedPhaseIds = $job->phase ? [(int) $job->phase->id] : [];
            session()->flash('success', 'Phase completed and the next configured phase is active.');
        } catch (Throwable $e) {
            $this->addError('phaseCompletion', $e->getMessage());
        }
    }

    public function openTask(int $id): void
    {
        $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($id);
        $this->selectedJobId = (int) $task->flow_job_id;
        $this->selectedTaskId = $task->id;
        $this->taskDocumentUploads = [];
        $this->taskExistingDocumentId = null;
        $this->showTaskDocumentPicker = false;
        $this->loadTaskForm($id);
    }

    public function closeTask(): void { $this->selectedTaskId = null; $this->taskComment = ''; $this->newChecklistItem = ''; $this->taskActivityTab = 'all'; $this->taskActivityPage = 1; $this->taskDocumentUploads = []; $this->taskExistingDocumentId = null; $this->showTaskDocumentPicker = false; }
    public function markTaskComplete(): void
    {
        abort_unless($this->selectedTaskId, 422);
        $this->resetErrorBag('taskCompletion');

        $task = app(TaskService::class)->visibleQuery(auth()->user())
            ->with(['documents','documentCategory','setupTemplate.documentCategory'])
            ->findOrFail($this->selectedTaskId);
        abort_unless(app(\App\Services\AccessControlService::class)->canEditTask(auth()->user(), $task), 403);

        app(TaskService::class)->moveStatus($task, 'Completed', auth()->user());
        $this->loadTaskForm($task->id);
        session()->flash('success', 'Task marked complete.');
    }

    public function addTaskComment(): void
    {
        if (!$this->selectedTaskId || trim($this->taskComment) === '') return;
        $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($this->selectedTaskId);
        app(TaskService::class)->addComment($task, $this->taskComment, auth()->user());
        $this->taskComment = '';
        $this->taskActivityPage = 1;
    }

    public function setTaskActivityTab(string $tab): void
    {
        abort_unless(in_array($tab, ['all','comments','history'], true), 422);
        $this->taskActivityTab = $tab;
        $this->taskActivityPage = 1;
    }

    public function setTaskActivityPage(int $page): void
    {
        $this->taskActivityPage = max(1, $page);
    }

    public function updateSelectedTaskField(string $field, mixed $value): void
    {
        if ($field === 'assignee_id') abort_unless(auth()->user()->canModule('tasks','assign'), 403);
        else abort_unless(auth()->user()->canAccess('tasks.update'), 403);
        abort_unless($this->selectedTaskId, 422);
        $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($this->selectedTaskId);
        if ($field === 'assignee_id' && filled($value)) User::where('is_active', true)->findOrFail((int) $value);
        if (in_array($field, ['start_date','due_date'], true) && filled($value)) validator(['date'=>$value], ['date'=>['date']])->validate();
        app(TaskService::class)->updateDetailField($task, $field, $value, auth()->user());
        $this->loadTaskForm($task->id);
    }

    public function addTaskChecklistItem(): void
    {
        abort_unless(auth()->user()->canAccess('tasks.update'), 403);
        abort_unless($this->selectedTaskId, 422);
        $this->validate(['newChecklistItem'=>['required','string','max:255']]);
        $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($this->selectedTaskId);
        app(TaskService::class)->addChecklistItem($task, $this->newChecklistItem, auth()->user());
        $this->newChecklistItem = '';
    }

    public function toggleTaskChecklistItem(int $itemId, bool $completed): void
    {
        abort_unless($this->selectedTaskId, 422);
        $task = app(TaskService::class)->visibleQuery(auth()->user())->with('checklistItems')->findOrFail($this->selectedTaskId);
        abort_unless(app(\App\Services\AccessControlService::class)->canEditTask(auth()->user(), $task), 403, 'Only the assigned person or an authorised administrator can complete checklist items.');
        $item = $task->checklistItems->firstWhere('id', $itemId);
        abort_unless($item, 404);
        app(TaskService::class)->toggleChecklistItem($task, $item, $completed, auth()->user());
    }

    public function deleteTaskChecklistItem(int $itemId): void
    {
        abort_unless(auth()->user()->canAccess('tasks.update'), 403);
        abort_unless($this->selectedTaskId, 422);
        $task = app(TaskService::class)->visibleQuery(auth()->user())->with('checklistItems')->findOrFail($this->selectedTaskId);
        $item = $task->checklistItems->firstWhere('id', $itemId);
        abort_unless($item, 404);
        app(TaskService::class)->deleteChecklistItem($task, $item, auth()->user());
    }

    public function setJobActivityTab(string $tab): void
    {
        abort_unless(in_array($tab, ['all','comments','history'], true), 422);
        $this->jobActivityTab = $tab;
        $this->jobActivityPage = 1;
    }

    public function setJobActivityPage(int $page): void
    {
        $this->jobActivityPage = max(1, $page);
    }

    public function addJobComment(): void
    {
        abort_unless($this->selectedJobId, 422);
        $body = trim($this->jobComment);
        if ($body === '') return;
        $job = app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        abort_unless(app(\App\Services\AccessControlService::class)->canEditJob(auth()->user(), $job), 403);
        $job->activities()->create([
            'user_id' => auth()->id(),
            'event' => 'job.comment',
            'description' => $body,
            'meta' => ['body' => $body],
        ]);
        app(\App\Services\NotificationService::class)->notifyJobParticipants(
            $job,
            'New comment on '.$job->job_number,
            $body,
            'comment',
            auth()->user(),
        );
        $this->jobComment = '';
        $this->jobActivityPage = 1;
    }

    public function uploadSelectedTaskDocuments(): void
    {
        abort_unless(auth()->user()->canModule('documents','create'), 403);
        abort_unless($this->selectedTaskId, 422);
        $task = app(TaskService::class)->visibleQuery(auth()->user())->with(['job','documentCategory','setupTemplate.documentCategory'])->findOrFail($this->selectedTaskId);
        $this->validate([
            'taskDocumentUploads' => ['required','array','min:1'],
            'taskDocumentUploads.*' => ['file','max:20480','mimes:pdf,doc,docx,xls,xlsx,jpg,jpeg,png,zip,txt,csv'],
        ]);
        foreach ($this->taskDocumentUploads as $upload) {
            app(\App\Services\DocumentService::class)->store($upload, ['flow_job_id'=>$task->flow_job_id,'client_id'=>$task->job?->client_id,'task_id'=>$task->id,'category'=>'Task attachment'], auth()->user());
        }
        $this->taskDocumentUploads = [];
        session()->flash('success', 'Attachment uploaded and linked to this Task Pack task.');
    }

    public function attachExistingToSelectedTask(): void
    {
        abort_unless(auth()->user()->canModule('documents','link'), 403);
        abort_unless($this->selectedTaskId, 422);
        $this->validate(['taskExistingDocumentId'=>['required','integer','exists:documents,id']]);
        $task = app(TaskService::class)->visibleQuery(auth()->user())->with(['job','documentCategory','setupTemplate.documentCategory'])->findOrFail($this->selectedTaskId);
        $source = Document::findOrFail((int)$this->taskExistingDocumentId);
        abort_unless((int) $source->client_id === (int) $task->job?->client_id, 403, 'The selected document does not belong to this client.');
        app(\App\Services\DocumentService::class)->linkExisting($source, $task, auth()->user(), true);
        $this->taskExistingDocumentId = null;
        $this->showTaskDocumentPicker = false;
        session()->flash('success', 'Stored document linked to this task.');
    }

    public function deleteSelectedTaskDocument(int $documentId): void
    {
        abort_unless(auth()->user()->canModule('documents','delete'), 403);
        abort_unless($this->selectedTaskId, 422);
        $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($this->selectedTaskId);
        $document = Document::where('task_id',$task->id)->findOrFail($documentId);
        app(\App\Services\DocumentService::class)->delete($document, auth()->user());
    }

    public function toggleTaskDocumentPicker(): void
    {
        $this->showTaskDocumentPicker = !$this->showTaskDocumentPicker;
    }

    public function toggleTaskAttention(): void
    {
        abort_unless(auth()->user()->canAccess('tasks.update'), 403);
        if (!$this->selectedTaskId) return;
        $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($this->selectedTaskId);
        $value = !(bool) $task->needs_attention;
        app(TaskService::class)->update($task, [
            'status' => $task->status,
            'assignee_id' => $task->assignee_id,
            'progress' => $task->progress,
            'needs_attention' => $value,
            'attention_reason' => $value ? ($task->attention_reason ?: 'Flagged for management attention') : null,
        ], auth()->user());
        $this->taskAttention = $value;
    }

    public function saveTask(): void
    {
        abort_unless(auth()->user()->canAccess('tasks.update'), 403);
        $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($this->selectedTaskId);
        $this->validate([
            'taskStatus' => ['required','string','max:50'],
            'taskAssigneeId' => ['nullable','exists:users,id'],
            'taskProgress' => ['required','integer','between:0,100'],
            'taskAttention' => ['boolean'],
            'taskAttentionReason' => [Rule::requiredIf($this->taskAttention || $this->taskStatus === 'Blocked'),'nullable','string','max:1000'],
        ]);
        app(TaskService::class)->update($task, [
            'status' => $this->taskStatus,
            'assignee_id' => $this->taskAssigneeId,
            'progress' => $this->taskProgress,
            'needs_attention' => $this->taskAttention,
            'attention_reason' => $this->taskAttentionReason,
        ], auth()->user());
        if (trim($this->taskComment) !== '') app(TaskService::class)->addComment($task, $this->taskComment, auth()->user());
        session()->flash('success', 'Task update saved.');
        $this->selectedTaskId = null;
        $this->taskComment = '';
    }

    private function loadTaskForm(int $id): void
    {
        $task = app(TaskService::class)->visibleQuery(auth()->user())->findOrFail($id);
        $this->taskStatus = $task->status;
        $this->taskAssigneeId = $task->assignee_id;
        $this->taskProgress = $task->progress;
        $this->taskAttention = $task->needs_attention;
        $this->taskAttentionReason = (string) $task->attention_reason;
        $this->taskComment = '';
        $this->newChecklistItem = '';
        $this->taskActivityTab = 'all';
        $this->taskActivityPage = 1;
    }

    private function setDefaultStartPhase(): void
    {
        $this->workflowPhaseId = WorkflowPhase::where('workflow_id', $this->workflowId)
            ->where('is_active', true)
            ->where('allow_job_start', true)
            ->orderBy('sequence')
            ->value('id');
    }

    private function prepareSelectedJob(int $id): void
    {
        $job = app(JobService::class)->visibleQuery(auth()->user())
            ->select(['id', 'workflow_phase_id'])
            ->findOrFail($id);

        if (!$this->expandedPhaseIds && $job->workflow_phase_id) {
            $this->expandedPhaseIds = [(int) $job->workflow_phase_id];
        }
    }

    private function setDefaultDocumentTask(?FlowJob $job = null): void
    {
        if (!$this->selectedJobId && !$job) return;
        $job ??= app(JobService::class)->findVisible(auth()->user(), $this->selectedJobId);
        $valid = $job->tasks->first(fn ($task) => (int) $task->id === (int) $this->jobDocumentTaskId && ($task->document_category_id || $task->setupTemplate?->document_category_id));
        if ($valid) return;

        $task = $job->tasks
            ->filter(fn ($task) => $task->document_category_id || $task->setupTemplate?->document_category_id)
            ->sortBy(fn ($task) => [
                (int) ($task->workflow_phase_id === $job->workflow_phase_id ? 0 : 1),
                (int) ($task->phase?->sequence ?? 999),
                (int) ($task->setupTemplate?->sort_order ?? 999),
            ])->first();
        $this->jobDocumentTaskId = $task?->id;
    }

    #[On('flowtrack-notification')]
    public function refreshRealtime(): void
    {
        // Re-render open Job/Task details when another permitted user updates them.
    }

    public function render()
    {
        $service = app(JobService::class);
        $master = app(MasterDataService::class);
        $user = auth()->user();

        $priorities = $master->active('priority');
        $canAssign = $user->canModule('tasks', 'assign') || $user->canModule('jobs', 'assign');
        $users = $canAssign
            ? User::where('is_active', true)->orderBy('name')->get(['id', 'name'])
            : collect([(object) ['id' => $user->id, 'name' => $user->name]]);

        if ($this->showCreate) {
            return view('livewire.jobs.index', [
                'selectedJob' => null,
                'selectedTask' => null,
                'clients' => app(\App\Services\ClientService::class)->visibleQuery($user)->where('is_active', true)->orderBy('name')->get(['id', 'name']),
                'workflows' => Workflow::with('phases.taskPack.items')->where('is_active', true)->get(),
                'users' => $users,
                'categories' => $master->active('product_category'),
                'products' => $master->active('product'),
                'priorities' => $priorities,
            ]);
        }

        if ($this->selectedTaskId) {
            $taskStatuses = collect(BoardLaneResolver::taskStatuses(
                $master->active('task_status')->pluck('name')
            ));
            $task = app(TaskService::class)->visibleQuery($user)->with([
                'job.client:id,name',
                'job.tasks' => fn ($query) => app(AccessControlService::class)
                    ->applyTaskScope($query, $user)
                    ->select(['tasks.id', 'tasks.flow_job_id', 'tasks.workflow_phase_id', 'tasks.title'])
                    ->orderBy('tasks.id'),
                'assignee', 'phase', 'documentCategory', 'setupTemplate.documentCategory',
                'checklistItems', 'comments.user', 'documents', 'activities.user',
            ])->findOrFail($this->selectedTaskId);

            $availableDocuments = $this->showTaskDocumentPicker
                ? app(\App\Services\DocumentService::class)
                    ->query($user, ['client' => $task->job?->client_id])
                    ->with(['job:id,job_number', 'task:id,title'])
                    ->latest('id')
                    ->limit(60)
                    ->get()
                : collect();

            return view('livewire.jobs.index', [
                'selectedJob' => null,
                'selectedTask' => $task,
                'users' => $users,
                'taskStatuses' => $taskStatuses,
                'priorities' => $priorities,
                'availableDocuments' => $availableDocuments,
            ]);
        }

        if ($this->selectedJobId) {
            $taskStatuses = collect(BoardLaneResolver::taskStatuses(
                $master->active('task_status')->pluck('name')
            ));
            $selected = $service->findVisible($user, $this->selectedJobId);
            $availableDocuments = $this->detailTab === 'documents'
                ? app(\App\Services\DocumentService::class)
                    ->query($user, ['client' => $selected->client_id])
                    ->with(['job:id,job_number', 'task:id,title'])
                    ->latest('id')
                    ->limit(60)
                    ->get()
                : collect();

            return view('livewire.jobs.index', [
                'selectedJob' => $selected,
                'selectedTask' => null,
                'taskStatuses' => $taskStatuses,
                'users' => $users,
                'priorities' => $priorities,
                'products' => $this->detailTab === 'overview' ? $master->active('product') : collect(),
                'categories' => $this->detailTab === 'overview' ? $master->active('product_category') : collect(),
                'availableDocuments' => $availableDocuments,
                'healthOptions' => collect(['On Track', 'At Risk', 'Delayed', 'Blocked', 'Completed']),
            ]);
        }

        $filters = $this->jobFilters();
        $jobs = $service->paginate($user, $filters, $this->perPage);

        return view('livewire.jobs.index', [
            'selectedJob' => null,
            'selectedTask' => null,
            'jobs' => $jobs,
            'jobSummary' => $service->summaryCounts($user),
            'clients' => app(\App\Services\ClientService::class)->visibleQuery($user)->where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'phases' => WorkflowPhase::where('is_active', true)->orderBy('sequence')->get(['id', 'name', 'short_name', 'sequence']),
            'users' => $users,
            'priorities' => $priorities,
            'healthOptions' => collect(['On Track', 'At Risk', 'Delayed', 'Blocked', 'Completed']),
            'jobStatuses' => $service->visibleQuery($user)->whereNotNull('status')->distinct()->orderBy('status')->pluck('status')->filter()->values(),
            'allFilteredJobsSelected' => $jobs->total() > 0 && count($this->selectedJobIds) === $jobs->total(),
        ]);
    }

    private function jobFilters(): array
    {
        return [
            'search' => $this->search,
            'phase' => $this->phase,
            'health' => $this->health,
            'client' => $this->client,
            'owner' => $this->owner,
            'delivery' => $this->delivery,
            'invoice' => $this->invoice,
            'priority' => $this->priorityFilter,
            'status' => $this->jobStatusFilter,
            'quick' => $this->quickFilter,
        ];
    }

    private function resetJobSelection(): void
    {
        $this->selectedJobIds = [];
        $this->resetPage();
    }
}
